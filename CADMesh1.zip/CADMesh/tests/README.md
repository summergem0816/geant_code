# CADMesh Tests

Tests are a work in progress. There files show what can be done, and the level to which CADMesh can be tested.

To run the tests, when you build CADMesh (as as library), make sure you have the optional dependencies installed:

```
cmake -D WITH_TESTS=ON .. 
make
make test
```
